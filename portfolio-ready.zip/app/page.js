export default function Home() {
  return (
    <main style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>👋 Hi, I'm Mahrukh</h1>
      <p>Senior AI Tech Architect & Full Stack Developer</p>

      <h2>🚀 Projects</h2>
      <ul>
        <li>MemesX App</li>
        <li>IntelMarkets ICO ($26M raised)</li>
        <li>LaunchX Wallet</li>
        <li>iBitt Exchange</li>
      </ul>

      <h2>📩 Contact</h2>
      <p>Email: your@email.com</p>
    </main>
  );
}